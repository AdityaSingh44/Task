<?php
// Setup PDO connection using Factory Pattern
class DatabaseFactory
{
    public static function createConnection()
    {
        return new PDO('mysql:host=localhost;dbname=contact_db', 'root', '');
    }
}

// Abstract Field class and concrete field types (TextInput, Checkbox, Select)
abstract class Field
{
    protected $name;
    protected $label;
    protected $value;

    public function __construct($name, $label, $value = '')
    {
        $this->name = $name;
        $this->label = $label;
        $this->value = $value;
    }

    abstract public function render();
}

class TextInput extends Field
{
    public function render()
    {
        return "<label for='{$this->name}'>{$this->label}</label>
                <input type='text' id='{$this->name}' name='{$this->name}' value='{$this->value}' />";
    }
}

class Checkbox extends Field
{
    public function render()
    {
        $checked = $this->value ? 'checked' : '';
        return "<label for='{$this->name}'>{$this->label}</label>
                <input type='checkbox' id='{$this->name}' name='{$this->name}' {$checked} />";
    }
}

class SelectField extends Field
{
    private $options;

    public function __construct($name, $label, $options = [], $value = '')
    {
        parent::__construct($name, $label, $value);
        $this->options = $options;
    }

    public function render()
    {
        $optionsHtml = '';
        foreach ($this->options as $key => $option) {
            $selected = ($key == $this->value) ? 'selected' : '';
            $optionsHtml .= "<option value='{$key}' {$selected}>{$option}</option>";
        }
        return "<label for='{$this->name}'>{$this->label}</label>
                <select id='{$this->name}' name='{$this->name}'>{$optionsHtml}</select>";
    }
}

// Form class that handles dynamic form generation
class Form
{
    private $fields = [];

    public function __construct($fieldsConfig)
    {
        foreach ($fieldsConfig as $config) {
            $this->addField($config);
        }
    }

    public function addField($config)
    {
        $type = $config['type'];
        $name = $config['name'];
        $label = $config['label'];
        $value = $config['value'] ?? '';
        $options = $config['options'] ?? [];

        switch ($type) {
            case 'text':
                $this->fields[] = new TextInput($name, $label, $value);
                break;
            case 'checkbox':
                $this->fields[] = new Checkbox($name, $label, $value);
                break;
            case 'select':
                $this->fields[] = new SelectField($name, $label, $options, $value);
                break;
        }
    }

    public function render()
    {
        $formHtml = "<form method='POST'>";
        foreach ($this->fields as $field) {
            $formHtml .= $field->render();
        }
        if (isset($_GET['action']) && $_GET['action'] === 'edit') {
            $formHtml .= "<input type='hidden' name='id' value='{$_GET['id']}'>";
        }
        $formHtml .= "<button type='submit'>Submit</button></form>";
        return $formHtml;
    }
}

// Contact class for CRUD operations
class Contact
{
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    public function create($name, $phone, $email, $address)
    {
        $stmt = $this->pdo->prepare("INSERT INTO contacts (name, phone, email, address) VALUES (:name, :phone, :email, :address)");
        $stmt->execute(['name' => $name, 'phone' => $phone, 'email' => $email, 'address' => $address]);
    }

    public function update($id, $name, $phone, $email, $address)
    {
        $stmt = $this->pdo->prepare("UPDATE contacts SET name = :name, phone = :phone, email = :email, address = :address WHERE id = :id");
        $stmt->execute([
            'name' => $name,
            'phone' => $phone,
            'email' => $email,
            'address' => $address,
            'id' => $id
        ]);
    }

    public function getAll()
    {
        $stmt = $this->pdo->query("SELECT * FROM contacts");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM contacts WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function delete($id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM contacts WHERE id = :id");
        $stmt->execute(['id' => $id]);
    }
}

// Handle request logic
$pdo = DatabaseFactory::createConnection();
$contactModel = new Contact($pdo);

// Handle form submission for creating or updating
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    if (isset($_POST['id'])) {
        $contactModel->update($_POST['id'], $name, $phone, $email, $address);
    } else {
        $contactModel->create($name, $phone, $email, $address);
    }

    // Redirect back to index.php after submission
    header("Location: index.php");
    exit;
}

// Handle edit action
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $contactData = $contactModel->getById($_GET['id']);
    $formConfig = [
        ['type' => 'text', 'name' => 'name', 'label' => 'Name', 'value' => $contactData['name']],
        ['type' => 'text', 'name' => 'phone', 'label' => 'Phone', 'value' => $contactData['phone']],
        ['type' => 'text', 'name' => 'email', 'label' => 'Email', 'value' => $contactData['email']],
        ['type' => 'text', 'name' => 'address', 'label' => 'Address', 'value' => $contactData['address']],
    ];
} else {
    // Default form configuration for adding new contact
    $formConfig = [
        ['type' => 'text', 'name' => 'name', 'label' => 'Name'],
        ['type' => 'text', 'name' => 'phone', 'label' => 'Phone'],
        ['type' => 'text', 'name' => 'email', 'label' => 'Email'],
        ['type' => 'text', 'name' => 'address', 'label' => 'Address'],
    ];
}

// Handle deletion
if (isset($_GET['delete'])) {
    $contactModel->delete($_GET['delete']);
    header("Location: index.php");
    exit;
}

// Display contacts and form
$contacts = $contactModel->getAll();
$form = new Form($formConfig);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Contact Manager</title>
</head>
<body>

<h1>Contact Manager</h1>

<?= $form->render(); ?>

<h2>Contact List</h2>
<table border="1">
    <tr>
        <th>Name</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Address</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($contacts as $contact): ?>
    <tr>
        <td><?= htmlspecialchars($contact['name']) ?></td>
        <td><?= htmlspecialchars($contact['phone']) ?></td>
        <td><?= htmlspecialchars($contact['email']) ?></td>
        <td><?= htmlspecialchars($contact['address']) ?></td>
        <td>
            <a href="?action=edit&id=<?= $contact['id'] ?>">Edit</a> |
            <a href="?delete=<?= $contact['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>